#!/bin/bash
python3 scanner.py scanme.nmap.org 20 123
